"""GPIPS India demo package."""

